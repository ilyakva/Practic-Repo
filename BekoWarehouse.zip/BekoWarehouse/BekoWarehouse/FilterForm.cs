﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BekoWarehouse
{
    public partial class FilterForm : Form
    {
        string connectionString =
            @"Data Source=pc2a;Initial Catalog=BekoWarehouse;Integrated Security=True;Encrypt=False";
        public FilterForm()
        {
            InitializeComponent();
        }

        private void FilterForm_Load(object sender, EventArgs e)
        {
            cmbTable.Items.Add("Categories");

            cmbTable.Items.Add("Products");

            cmbTable.Items.Add("Warehouses");

            cmbTable.Items.Add("Employees");

            cmbTable.Items.Add("Deliveries");

            cmbTable.SelectedIndex = 0;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string table = cmbTable.Text;

            string column = "";


            if (table == "Categories")
                column = "category_name";

            else if (table == "Products")
                column = "product_name";

            else if (table == "Warehouses")
                column = "warehouse_name";

            else if (table == "Employees")
                column = "full_name";

            else if (table == "Deliveries")
                column = "delivery_date";



            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query =
                $"SELECT * FROM {table} WHERE {column} LIKE @search";


                SqlDataAdapter da =
                    new SqlDataAdapter(query, con);


                da.SelectCommand.Parameters.AddWithValue(
                    "@search",
                    "%" + txtSearch.Text + "%"
                );


                DataTable dt = new DataTable();


                da.Fill(dt);


                dgvFilter.DataSource = dt;
            }
        }
    }
}
