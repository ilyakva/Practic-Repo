﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BekoWarehouse
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bekoWarehouseDataSet.Warehouses". При необходимости она может быть перемещена или удалена.
            this.warehousesTableAdapter.Fill(this.bekoWarehouseDataSet.Warehouses);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bekoWarehouseDataSet.Products". При необходимости она может быть перемещена или удалена.
            this.productsTableAdapter.Fill(this.bekoWarehouseDataSet.Products);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bekoWarehouseDataSet.Employees". При необходимости она может быть перемещена или удалена.
            this.employeesTableAdapter.Fill(this.bekoWarehouseDataSet.Employees);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bekoWarehouseDataSet.Deliveries". При необходимости она может быть перемещена или удалена.
            this.deliveriesTableAdapter.Fill(this.bekoWarehouseDataSet.Deliveries);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bekoWarehouseDataSet.Categories". При необходимости она может быть перемещена или удалена.
            this.categoriesTableAdapter.Fill(this.bekoWarehouseDataSet.Categories);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=pc2a;Initial Catalog=BekoWarehouse;Integrated Security=True;Encrypt=False";

            string table = "";

            string idColumn = "";

            DataGridView dgv = null;

            // Определяем, какая вкладка открыта

            if (tabControl.SelectedTab == tabPage1)

            {

                table = "Categories";

                idColumn = "category_id";

                dgv = dataGridView1;

            }

            else if (tabControl.SelectedTab == tabPage2)

            {

                table = "Products";

                idColumn = "product_id";

                dgv = dataGridView2;

            }

            else if (tabControl.SelectedTab == tabPage3)

            {

                table = "Warehouses";

                idColumn = "warehouse_id";

                dgv = dataGridView3;

            }

            else if (tabControl.SelectedTab == tabPage4)

            {

                table = "Employees";

                idColumn = "employee_id";

                dgv = dataGridView4;

            }

            else if (tabControl.SelectedTab == tabPage5)

            {

                table = "Deliveries";

                idColumn = "delivery_id";

                dgv = dataGridView5;

            }

            if (dgv.SelectedRows.Count == 0)

            {

                MessageBox.Show("Выберите запись для удаления");

                return;

            }

            int id = Convert.ToInt32(dgv.SelectedRows[0].Cells[0].Value);


            using (SqlConnection con = new SqlConnection(connectionString))

            {

                string query =

                    $"DELETE FROM {table} WHERE {idColumn} = @id";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@id", id);

                con.Open();

                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("Запись удалена");

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddForm form = new AddForm();
            form.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FilterForm filterForm = new FilterForm();
            filterForm.ShowDialog();
        }
    }
}
