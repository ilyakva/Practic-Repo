﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BekoWarehouse
{
    public partial class AddForm : Form
    {
        public AddForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=pc2a;Initial Catalog=BekoWarehouse;Integrated Security=True;Encrypt=False";

            using (SqlConnection con = new SqlConnection(connectionString))

            {

                string query =

                    "INSERT INTO Categories (category_name) VALUES (@name)";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@name", textBox1.Text);

                con.Open();

                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("Категория добавлена!");

            }
        }
    }
}
